﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalBot.Domain
{
    public class Usuario
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public long Chat { get; set; }
        public Fluxo Fluxo { get; set; }
        public string Cpf { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }

        public Usuario(string nome, long chat, Fluxo fluxo)
        {
            Nome = nome;
            Chat = chat;
            Fluxo = fluxo;
        }
    }
}
